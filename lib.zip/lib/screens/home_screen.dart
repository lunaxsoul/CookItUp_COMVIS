import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';

import '../services/classifier_service.dart';
import 'result_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.classifier});

  final ClassifierService classifier;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _picker = ImagePicker();

  File? _selectedImage;
  bool _isClassifying = false;
  String? _errorMessage;

  Future<void> _pickImage(ImageSource source) async {
    setState(() => _errorMessage = null);

    try {
      final picked = await _picker.pickImage(
        source: source,
        imageQuality: 90,
      );

      if (picked == null) return;

      final cropped = await _cropImage(picked.path);

      if (cropped == null) return;

      setState(() {
        _selectedImage = File(cropped.path);
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal mengambil gambar: $e';
      });
    }
  }

  Future<CroppedFile?> _cropImage(String sourcePath) {
    return ImageCropper().cropImage(
      sourcePath: sourcePath,
      compressQuality: 90,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Potong Gambar Makanan',
          toolbarColor: Theme.of(context).colorScheme.primary,
          toolbarWidgetColor: Colors.white,
          initAspectRatio: CropAspectRatioPreset.square,
          lockAspectRatio: false,
        ),
        IOSUiSettings(
          title: 'Potong Gambar Makanan',
        ),
      ],
    );
  }

  Future<void> _analyzeImage() async {
    final image = _selectedImage;

    if (image == null) return;

    setState(() {
      _isClassifying = true;
      _errorMessage = null;
    });

    try {
      final prediction = await widget.classifier.classify(image);

      if (!mounted) return;

      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            prediction: prediction,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _errorMessage = 'Gagal menganalisis gambar: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isClassifying = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F7F2),
      body: SafeArea(
        child: Stack(
          children: [
            _buildDecorations(),

            SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(28, 20, 28, 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildBackButton(),

                    const SizedBox(height: 38),

                    const Text(
                      'Choose a food photo',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF183B32),
                        height: 1.15,
                      ),
                    ),

                    const SizedBox(height: 12),

                    const Text(
                      'Select a clear photo of your meal\n'
                          'for better recognition.',
                      style: TextStyle(
                        fontSize: 16,
                        height: 1.45,
                        color: Color(0xFF78928B),
                      ),
                    ),

                    const SizedBox(height: 65),

                    Center(
                      child: GestureDetector(
                        onTap: _isClassifying
                            ? null
                            : () => _pickImage(ImageSource.camera),
                        child: _buildImageCircle(),
                      ),
                    ),

                    const SizedBox(height: 55),

                    if (_errorMessage != null) ...[
                      Text(
                        _errorMessage!,
                        style: const TextStyle(
                          color: Color(0xFFB23A3A),
                          fontSize: 13,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                    ],

                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: ElevatedButton(
                        onPressed: _isClassifying
                            ? null
                            : () => _pickImage(ImageSource.gallery),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF285F53),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          'From Gallery',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),

                    if (_selectedImage != null) ...[
                      const SizedBox(height: 16),

                      SizedBox(
                        width: double.infinity,
                        height: 58,
                        child: ElevatedButton(
                          onPressed: _isClassifying
                              ? null
                              : _analyzeImage,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF183B32),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: _isClassifying
                              ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                              : const Text(
                            'Analyze',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],

                    const SizedBox(height: 16),

                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: OutlinedButton(
                        onPressed: _isClassifying
                            ? null
                            : () {
                          if (_selectedImage != null) {
                            setState(() {
                              _selectedImage = null;
                              _errorMessage = null;
                            });
                          } else {
                            Navigator.of(context).maybePop();
                          }
                        },
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFF285F53),
                          side: const BorderSide(
                            color: Color(0xFFAFC4BE),
                            width: 1.3,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: Text(
                          _selectedImage != null
                              ? 'Cancel'
                              : 'Cancel',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageCircle() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: 190,
      height: 190,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color(0xFFEEF1E7),
      ),
      child: _selectedImage == null
          ? const Center(
        child: Icon(
          Icons.image_outlined,
          size: 72,
          color: Color(0xFF285F53),
        ),
      )
          : ClipOval(
        child: Image.file(
          _selectedImage!,
          width: 190,
          height: 190,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  Widget _buildBackButton() {
    return IconButton(
      onPressed: () => Navigator.of(context).maybePop(),
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(
        minWidth: 40,
        minHeight: 40,
      ),
      icon: const Icon(
        Icons.arrow_back,
        size: 27,
        color: Color(0xFF183B32),
      ),
    );
  }

  Widget _buildDecorations() {
    return IgnorePointer(
      child: Align(
        alignment: Alignment.bottomRight,
        child: Padding(
          padding: const EdgeInsets.only(
            right: 18,
            bottom: 8,
          ),
          child: Opacity(
            opacity: 0.28,
            child: Icon(
              Icons.spa_outlined,
              size: 95,
              color: const Color(0xFFA8C3A0),
            ),
          ),
        ),
      ),
    );
  }
}
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:image_cropper/image_cropper.dart';
// import 'package:image_picker/image_picker.dart';
//
// import '../services/classifier_service.dart';
// import 'result_screen.dart';
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key, required this.classifier});
//
//   final ClassifierService classifier;
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   final _picker = ImagePicker();
//
//   File? _selectedImage;
//   bool _isClassifying = false;
//   String? _errorMessage;
//
//   Future<void> _pickImage(ImageSource source) async {
//     setState(() => _errorMessage = null);
//     try {
//       final picked = await _picker.pickImage(source: source, imageQuality: 90);
//       if (picked == null) return;
//
//       final cropped = await _cropImage(picked.path);
//       if (cropped == null) return;
//
//       setState(() => _selectedImage = File(cropped.path));
//     } catch (e) {
//       setState(() => _errorMessage = 'Gagal mengambil gambar: $e');
//     }
//   }
//
//   Future<CroppedFile?> _cropImage(String sourcePath) {
//     return ImageCropper().cropImage(
//       sourcePath: sourcePath,
//       compressQuality: 90,
//       uiSettings: [
//         AndroidUiSettings(
//           toolbarTitle: 'Potong Gambar Makanan',
//           toolbarColor: Theme.of(context).colorScheme.primary,
//           toolbarWidgetColor: Colors.white,
//           initAspectRatio: CropAspectRatioPreset.square,
//           lockAspectRatio: false,
//         ),
//         IOSUiSettings(title: 'Potong Gambar Makanan'),
//       ],
//     );
//   }
//
//   Future<void> _analyzeImage() async {
//     final image = _selectedImage;
//     if (image == null) return;
//
//     setState(() {
//       _isClassifying = true;
//       _errorMessage = null;
//     });
//
//     try {
//       final prediction = await widget.classifier.classify(image);
//       if (!mounted) return;
//
//       await Navigator.of(context).push(
//         MaterialPageRoute(
//           builder: (_) => ResultScreen(prediction: prediction),
//         ),
//       );
//     } catch (e) {
//       setState(() => _errorMessage = 'Gagal menganalisis gambar: $e');
//     } finally {
//       if (mounted) setState(() => _isClassifying = false);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Food Classifier')),
//       body: SafeArea(
//         child: Padding(
//           padding: const EdgeInsets.all(20),
//           child: Column(
//             children: [
//               Expanded(child: _buildPreview()),
//               if (_errorMessage != null) ...[
//                 const SizedBox(height: 12),
//                 Text(
//                   _errorMessage!,
//                   style: TextStyle(color: Theme.of(context).colorScheme.error),
//                   textAlign: TextAlign.center,
//                 ),
//               ],
//               const SizedBox(height: 16),
//               Row(
//                 children: [
//                   Expanded(
//                     child: OutlinedButton.icon(
//                       onPressed: _isClassifying ? null : () => _pickImage(ImageSource.camera),
//                       icon: const Icon(Icons.photo_camera_outlined),
//                       label: const Text('Kamera'),
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   Expanded(
//                     child: OutlinedButton.icon(
//                       onPressed: _isClassifying ? null : () => _pickImage(ImageSource.gallery),
//                       icon: const Icon(Icons.photo_library_outlined),
//                       label: const Text('Galeri'),
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               SizedBox(
//                 width: double.infinity,
//                 child: FilledButton.icon(
//                   onPressed: _selectedImage == null || _isClassifying ? null : _analyzeImage,
//                   icon: _isClassifying
//                       ? const SizedBox(
//                           width: 18,
//                           height: 18,
//                           child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
//                         )
//                       : const Icon(Icons.search),
//                   label: Text(_isClassifying ? 'Menganalisis...' : 'Analisis Gambar'),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildPreview() {
//     final image = _selectedImage;
//     if (image == null) {
//       return Container(
//         decoration: BoxDecoration(
//           color: Theme.of(context).colorScheme.surfaceContainerHighest,
//           borderRadius: BorderRadius.circular(16),
//         ),
//         alignment: Alignment.center,
//         child: const Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Icon(Icons.fastfood_outlined, size: 64, color: Colors.grey),
//             SizedBox(height: 12),
//             Text('Ambil atau pilih foto makanan\nuntuk diidentifikasi', textAlign: TextAlign.center),
//           ],
//         ),
//       );
//     }
//
//     return ClipRRect(
//       borderRadius: BorderRadius.circular(16),
//       child: Image.file(image, fit: BoxFit.cover, width: double.infinity),
//     );
//   }
// }
